# CodeWeekend Spring 2016

## Chat App

Source code for Penn’s Spring 2016 CodeWeekend.

## How to run

To run the client, simply use a web browser to open `index.html` in `/client`.

To run the server, install node and navigate to `/server`. Run `npm install` and
then `node server.js`.
